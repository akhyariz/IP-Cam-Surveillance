<?php session_start(); include('snews.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<?php title(); ?>	
	<meta name="Robots" content="index,follow" />
	<meta name="Generator" content="sNews 1.6" />
	<link rel="stylesheet" type="text/css" href="style.css" media="screen" />
	<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="rss-articles/" />
	<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="rss-pages/" />
	<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="rss-comments/" />
</head>
<body>
	<div class="wrap">
		<div id="logo">
			<h1><?php echo s('website_title'); ?></h1>
		</div>
		
		<ul id="menu">
			<?php pages(); ?>
		</ul>
		
		<div id="subheader">
			<div id="breadcrumbs">
				<?php breadcrumbs(); ?>
			</div>
			
			<div id="search">
				<?php searchform(); ?>
			</div>	
		</div>
		
		<div id="left">
			<h3>Categories:</h3>
			<ul>
				<?php categories(); ?>
			</ul>
			
			<h3>New Articles:</h3>
			<ul>
				<?php menu_articles(0,3); ?>
			</ul>
			
			<h3>New comments:</h3>
			<ul>
				<?php new_comments(5, 30); ?>
			</ul>
					
			<?php extra(); ?>
		</div>
				
		<div id="right">
			<?php center(); ?>
		</div>
	
		<div id="footer">
			<ul id="rss">
				<?php rss_links(); ?>
			</ul>
			<p>Barbecued by <a href="http://snewscms.com/" title="Single file CMS">sNews</a> &middot; <?php login_link(); ?></p>
		</div>
	</div>
</body>
</html>